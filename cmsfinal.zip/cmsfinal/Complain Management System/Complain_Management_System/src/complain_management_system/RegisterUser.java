package complain_management_system;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class RegisterUser {

    DbConnection dbcon_obj = new DbConnection();
    Connection con = dbcon_obj.EstablishConnection();
    Connection cona = dbcon_obj.AdminConnection();
    Statement stmt = null;
    PreparedStatement pstmt = null;
    ResultSet rset = null;

    public boolean LoginAdmin(String uname, String upass) {
        String loginString = "select * from tbl_login where Username='" + uname + "' and Userpass='" + upass + "'";

        boolean b;
        try {
            pstmt = cona.prepareStatement(loginString);
            rset = pstmt.executeQuery();
            if (rset.next()) {
                b = true;
            } else {
                b = false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            b = false;

        }
        return b;
    }

    public boolean LoginUser(String uname, String upass) {
        String loginString = "select * from tbl_login where Username='" + uname + "' and Userpass='" + upass + "'";
        boolean b;
        try {
            pstmt = con.prepareStatement(loginString);
            rset = pstmt.executeQuery();
            if (rset.next()) {
                b = true;
            } else {
                b = false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            b = false;

        }
        return b;

    }

    public boolean addInfo(String fname, String pass, String address, String email, String phonenumber, String gender, String username, String deparment) {
        boolean b = false;
        String sql = "insert into tbl_login(Username,Userpass,Phonenumber,Address,Gender,Email,fullname,department)"
                + "values('" + username + "','" + pass + "','" + phonenumber + "','" + address + "','" + gender + "','" + email + "','" + fname + "','" + deparment + "')";

        try {
            stmt = con.createStatement();
            int rset = stmt.executeUpdate(sql);
            if (rset > 0) {
                b = true;
            } else {
                b = false;
            }
        } catch (Exception e) {
        }
        return b;
    }

    public boolean deleteInfo(int ID) {
        boolean b = false;
        String sql = "delete from tbl_login where ID = '" + ID + "'";

        try {
            stmt = con.createStatement();
            int rset = stmt.executeUpdate(sql);
            if (rset > 0) {
                b = true;
            } else {
                b = false;
            }
        } catch (Exception e) {
        }
        return b;
    }

    public String name;
    public String pass, mail, number, department;

    public boolean FetchUser(int ID) {
        String loginString = "select * from tbl_login where ID='" + ID + "'";

        boolean b = false;
        try {
            pstmt = con.prepareStatement(loginString);
            rset = pstmt.executeQuery();
            while (rset.next()) {
                name = rset.getString("Username");
                pass = rset.getString("Userpass");
                mail = rset.getString("Email");
                number = rset.getString("Phonenumber");
                department = rset.getString("department");
            }
            b = true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            b = false;

        }
        return b;

    }

    public String[] getUser() {
        String[] userDetails = new String[4];
        userDetails[0] = name;
        userDetails[1] = number;
        userDetails[2] = mail;
        userDetails[3] = department;

        return userDetails;
    }

    public boolean FetchUser(String uname) {
        String loginString = "select * from tbl_login where Username='" + uname + "'";

        boolean b = false;
        try {
            pstmt = con.prepareStatement(loginString);
            rset = pstmt.executeQuery();
            if (rset.next()) {
                name = rset.getString("Username");
                pass = rset.getString("Userpass");
                mail = rset.getString("Email");
                number = rset.getString("Phonenumber");
                department = rset.getString("department");
                b = true;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            b = false;

        }
        return b;

    }

    public boolean UpdateUser(int ID, String uname, String upass, String mail, String address, String number, String fname, String depart) {

        boolean b = false;
        try {
            String sql = "update tbl_login set Username='" + uname + "', Userpass='" + upass + "', Phonenumber='" + number + "', Address='" + address + "',department='" + depart + "' ,Fullname='" + fname + "', Email='" + mail + "' where ID='" + ID + "'";

            stmt = con.createStatement();
            int rset = stmt.executeUpdate(sql);
            b = true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            b = false;

        }
        return b;
    }

    public int getID() {
        String sql = "SELECT * FROM id ";
        int id = 0;
        try {
            stmt = con.createStatement();
            rset = stmt.executeQuery(sql);
            while (rset.next()) {
                id = rset.getInt("id");
            }
        } catch (SQLException ex) {
            Logger.getLogger(RegisterUser.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }

    public void save(String name,String phone,String email,String department, String complaint) {
        String sql = "INSERT INTO id(name,phone,email,department,complain) "
                + "VALUES ('" + name+ "','"+phone+"','"+email+"','" + department + "','" + complaint + "')";
        try {
            stmt = con.createStatement();
            int rset = stmt.executeUpdate(sql);
            if (rset > 0) {
              
            } else {
            
            }
        } catch (Exception e) {
        }
    }

    public void getData(JTable jtable) {
        String sql = "SELECT * FROM id ";

        try {
            stmt = con.createStatement();
            rset = stmt.executeQuery(sql);
            while (rset.next()) {
                String id = String.valueOf(rset.getInt("id"));
                String name = rset.getString("name");
                String phone = rset.getString("phone");
                String email = rset.getString("email");
                String department = rset.getString("department");
                String complain = rset.getString("complain");
                String solution = rset.getString("solution");
                String[] data = {id, name, phone, email, department, complain, solution};
                DefaultTableModel dm = (DefaultTableModel) jtable.getModel();
                dm.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RegisterUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setD(int id, String solution) {
        String sql = "UPDATE id SET solution='" + solution + "'WHERE id='" + id + "'";
        try {
            stmt = con.createStatement();
            int rset = stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(RegisterUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String FetchSoln(int ID, String name) {
        String loginString = "SELECT * FROM id WHERE ID='" + ID + "' and Name='"+name+"'";
        try {
            pstmt = con.prepareStatement(loginString);
            rset = pstmt.executeQuery();
            while (rset.next()) {
                String solution = rset.getString("solution");
                name = rset.getString("name");
                return solution;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
        return "";

    }

    public void overwriteSoln(int complainID, String soln) {
        try {
            setD(complainID, soln);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void returnTable(JTable jtable) {

        JTable table;
        DefaultTableModel dm = (DefaultTableModel) jtable.getModel();
    }
}
