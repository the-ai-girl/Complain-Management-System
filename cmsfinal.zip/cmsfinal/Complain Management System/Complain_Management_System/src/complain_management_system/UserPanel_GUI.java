/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain_management_system;

import javax.swing.JOptionPane;

public class UserPanel_GUI extends javax.swing.JFrame {
    DbConnection con=new DbConnection();

    public UserPanel_GUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblUserName = new javax.swing.JLabel();
        lblUserPassword = new javax.swing.JLabel();
        btnUserPanel = new javax.swing.JButton();
        txtUserName = new javax.swing.JTextField();
        pwdUserPassword = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUserName.setBackground(new java.awt.Color(244, 222, 233));
        lblUserName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblUserName.setForeground(new java.awt.Color(102, 102, 102));
        lblUserName.setText("User Name:");
        lblUserName.setOpaque(true);
        getContentPane().add(lblUserName, new org.netbeans.lib.awtextra.AbsoluteConstraints(126, 126, -1, -1));

        lblUserPassword.setBackground(new java.awt.Color(244, 222, 233));
        lblUserPassword.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblUserPassword.setForeground(new java.awt.Color(102, 102, 102));
        lblUserPassword.setText("Password:");
        lblUserPassword.setOpaque(true);
        getContentPane().add(lblUserPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(126, 200, 80, -1));

        btnUserPanel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnUserPanel.setText("LOGIN");
        btnUserPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(153, 0, 153)));
        btnUserPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserPanelActionPerformed(evt);
            }
        });
        getContentPane().add(btnUserPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 260, 100, 40));

        txtUserName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUserNameActionPerformed(evt);
            }
        });
        getContentPane().add(txtUserName, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 123, 110, -1));
        getContentPane().add(pwdUserPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 197, 110, -1));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton1.setText("Go Back <-");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Desktop\\mai.jpg")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 590, 410));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnUserPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserPanelActionPerformed
        // TODO add your handling code here:
        con.EstablishConnection();
        String Un=txtUserName.getText();
        String Up=pwdUserPassword.getText();
        
        RegisterUser log=new RegisterUser();
        boolean b=log.LoginUser(Un, Up);
        if(b){
            JOptionPane.showMessageDialog(null,"Logged In");
            UserScreen u=new UserScreen(Un);
            u.setVisible(true);
        }
        else {
        JOptionPane.showMessageDialog(null, "Invalid Credentials!");}
        
        
        this.setVisible(false);
        
    }//GEN-LAST:event_btnUserPanelActionPerformed

    private void txtUserNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUserNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUserNameActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         this.setVisible(false);
        Main_GUI m=new Main_GUI();
        m.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(UserPanel_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(UserPanel_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(UserPanel_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(UserPanel_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new UserPanel_GUI().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnUserPanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblUserName;
    private javax.swing.JLabel lblUserPassword;
    private javax.swing.JPasswordField pwdUserPassword;
    private javax.swing.JTextField txtUserName;
    // End of variables declaration//GEN-END:variables
}
