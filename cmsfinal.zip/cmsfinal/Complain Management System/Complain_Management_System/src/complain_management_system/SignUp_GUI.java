
package complain_management_system;

import java.awt.Component;
import java.awt.Event;
import javax.swing.JComboBox;

import javax.swing.JOptionPane;

public class SignUp_GUI extends javax.swing.JFrame {
   DbConnection con_obj=new DbConnection();
   RegisterUser log=new RegisterUser();
 
    public SignUp_GUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        lblFullName_Signup = new javax.swing.JLabel();
        lblPhoneNumber_Signup = new javax.swing.JLabel();
        lblUserName_Signup = new javax.swing.JLabel();
        lblEmail_Signup = new javax.swing.JLabel();
        lblAddress_Signup = new javax.swing.JLabel();
        btnRegister_Signup = new javax.swing.JButton();
        txtFirstName_Signup = new javax.swing.JTextField();
        txtPhoneNumber_Signup = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtUsername_Signup = new javax.swing.JTextField();
        pwdPassword_signup = new javax.swing.JPasswordField();
        txtEmail_Signup = new javax.swing.JTextField();
        lblGender_Signup = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtareaAddress_Signup = new javax.swing.JTextArea();
        rbtnMale_Signup = new javax.swing.JRadioButton();
        rbtnFemale_Signup = new javax.swing.JRadioButton();
        rbtnNotosay_Signup = new javax.swing.JRadioButton();
        Terms_Signup = new javax.swing.JCheckBox();
        msg = new javax.swing.JLabel();
        lblfullnamemsg = new javax.swing.JLabel();
        lblphonenumbermsg = new javax.swing.JLabel();
        lblusernamemsg = new javax.swing.JLabel();
        lblpwdmsg = new javax.swing.JLabel();
        lblemailmsg = new javax.swing.JLabel();
        lblgendermsg = new javax.swing.JLabel();
        lbladdressmsg = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtdept = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblFullName_Signup.setBackground(new java.awt.Color(244, 222, 233));
        lblFullName_Signup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblFullName_Signup.setForeground(new java.awt.Color(102, 102, 102));
        lblFullName_Signup.setText("Full Name:");
        lblFullName_Signup.setOpaque(true);
        getContentPane().add(lblFullName_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 100, -1));

        lblPhoneNumber_Signup.setBackground(new java.awt.Color(244, 222, 233));
        lblPhoneNumber_Signup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblPhoneNumber_Signup.setForeground(new java.awt.Color(102, 102, 102));
        lblPhoneNumber_Signup.setText("Phone Number:");
        lblPhoneNumber_Signup.setAutoscrolls(true);
        lblPhoneNumber_Signup.setOpaque(true);
        getContentPane().add(lblPhoneNumber_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 120, -1));

        lblUserName_Signup.setBackground(new java.awt.Color(244, 222, 233));
        lblUserName_Signup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblUserName_Signup.setForeground(new java.awt.Color(102, 102, 102));
        lblUserName_Signup.setText("UserName:");
        lblUserName_Signup.setOpaque(true);
        getContentPane().add(lblUserName_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 100, -1));

        lblEmail_Signup.setBackground(new java.awt.Color(244, 222, 233));
        lblEmail_Signup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblEmail_Signup.setForeground(new java.awt.Color(102, 102, 102));
        lblEmail_Signup.setText("Email Address:");
        lblEmail_Signup.setOpaque(true);
        getContentPane().add(lblEmail_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 120, -1));

        lblAddress_Signup.setBackground(new java.awt.Color(244, 222, 233));
        lblAddress_Signup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblAddress_Signup.setForeground(new java.awt.Color(102, 102, 102));
        lblAddress_Signup.setText("Address:");
        lblAddress_Signup.setAutoscrolls(true);
        lblAddress_Signup.setOpaque(true);
        getContentPane().add(lblAddress_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 80, -1));

        btnRegister_Signup.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnRegister_Signup.setText("Register");
        btnRegister_Signup.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(153, 0, 153)));
        btnRegister_Signup.setEnabled(false);
        btnRegister_Signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegister_SignupActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegister_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 330, 90, 40));

        txtFirstName_Signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFirstName_SignupActionPerformed(evt);
            }
        });
        getContentPane().add(txtFirstName_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, 143, -1));
        getContentPane().add(txtPhoneNumber_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 50, 143, -1));

        jLabel1.setBackground(new java.awt.Color(244, 222, 233));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Password:");
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 90, -1));
        getContentPane().add(txtUsername_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, 143, -1));
        getContentPane().add(pwdPassword_signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, 143, -1));

        txtEmail_Signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmail_SignupActionPerformed(evt);
            }
        });
        getContentPane().add(txtEmail_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 170, 143, -1));

        lblGender_Signup.setBackground(new java.awt.Color(244, 222, 233));
        lblGender_Signup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblGender_Signup.setForeground(new java.awt.Color(102, 102, 102));
        lblGender_Signup.setText("Gender:");
        lblGender_Signup.setOpaque(true);
        getContentPane().add(lblGender_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 80, -1));

        txtareaAddress_Signup.setColumns(20);
        txtareaAddress_Signup.setRows(5);
        jScrollPane1.setViewportView(txtareaAddress_Signup);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, -1, 50));

        rbtnMale_Signup.setText("Male");
        rbtnMale_Signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnMale_SignupActionPerformed(evt);
            }
        });
        getContentPane().add(rbtnMale_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 250, -1, -1));

        rbtnFemale_Signup.setText("Female");
        rbtnFemale_Signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnFemale_SignupActionPerformed(evt);
            }
        });
        getContentPane().add(rbtnFemale_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, -1, -1));

        rbtnNotosay_Signup.setText("Prefer Not To Say");
        rbtnNotosay_Signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnNotosay_SignupActionPerformed(evt);
            }
        });
        getContentPane().add(rbtnNotosay_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 250, -1, 20));

        Terms_Signup.setText("Is The Information Provided Above Is True?");
        Terms_Signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Terms_SignupActionPerformed(evt);
            }
        });
        getContentPane().add(Terms_Signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, -1));
        getContentPane().add(msg, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 543, 277, 31));
        getContentPane().add(lblfullnamemsg, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 40, 143, 17));
        getContentPane().add(lblphonenumbermsg, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 143, 16));
        getContentPane().add(lblusernamemsg, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 140, 143, 16));
        getContentPane().add(lblpwdmsg, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 200, 134, 15));
        getContentPane().add(lblemailmsg, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 210, 135, 14));
        getContentPane().add(lblgendermsg, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 354, 150, 14));
        getContentPane().add(lbladdressmsg, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 465, 150, 17));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton1.setText("Go Back <-");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(474, 7, -1, -1));

        jLabel2.setBackground(new java.awt.Color(244, 222, 233));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Department:");
        jLabel2.setOpaque(true);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 110, -1));
        getContentPane().add(txtdept, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 210, 143, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Desktop\\mai.jpg")); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -20, 570, 410));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    public String getGender(){
    if(rbtnMale_Signup.isSelected()){
    return "Male";
    }else if(rbtnFemale_Signup.isSelected()){
    return "Female";
    }else
    {
    return "Not Mentioned";
    }
    }
    
    private void btnRegister_SignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegister_SignupActionPerformed
        // TODO add your handling code here:
       
     
        UserPanel_GUI a=new UserPanel_GUI();
        con_obj.EstablishConnection();
          if(txtFirstName_Signup.getText().trim().isEmpty()&&txtUsername_Signup.getText().trim().isEmpty()&&txtPhoneNumber_Signup.getText().trim().isEmpty()&&txtareaAddress_Signup.getText().trim().isEmpty()&&txtEmail_Signup.getText().trim().isEmpty()&&pwdPassword_signup.getText().trim().isEmpty()){
        lblfullnamemsg.setText("This field is empty!!");
        lblusernamemsg.setText("This field is empty!!");
        lblpwdmsg.setText("This field is empty!!");
        lblphonenumbermsg.setText("This field is empty!!");
        lblemailmsg.setText("This field is empty!!");
        lblgendermsg.setText("This field is empty!!");
        lbladdressmsg.setText("This field is empty!!");
        }else if(txtFirstName_Signup.getText().trim().isEmpty()){
            lblfullnamemsg.setText("This field is empty!!");
        }
        else if(txtUsername_Signup.getText().trim().isEmpty()){
            lblusernamemsg.setText("This field is empty!!");
        }
        else if(txtPhoneNumber_Signup.getText().trim().isEmpty()){
             lblphonenumbermsg.setText("This field is empty!!");
        }
        else if(txtareaAddress_Signup.getText().trim().isEmpty()){
             lbladdressmsg.setText("This field is empty!!");
        }
        else if(txtEmail_Signup.getText().trim().isEmpty()){
              lblemailmsg.setText("This field is empty!!");
        }
        else if(pwdPassword_signup.getText().trim().isEmpty()){
            lblpwdmsg.setText("This field is empty!!");
        }
        
        else{
      
        String fname=txtFirstName_Signup.getText();
        String uname=txtUsername_Signup.getText();
        String phone=txtPhoneNumber_Signup.getText();
        String address=txtareaAddress_Signup.getText();
        String email=txtEmail_Signup.getText();
        String pass=pwdPassword_signup.getText();
        String dept=txtdept.getText();
        String gender=getGender();
        boolean b = log.addInfo(fname, pass, address, email, phone, gender, uname,dept);
        if(b){
        JOptionPane.showMessageDialog(null, "Inserted");
        
        }
        else
        {
        JOptionPane.showMessageDialog(null,"Error");
        }
        
        a.setVisible(true);
        
        }
        
    }//GEN-LAST:event_btnRegister_SignupActionPerformed

    private void Terms_SignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Terms_SignupActionPerformed
        // TODO add your handling code here:
        if(Terms_Signup.isSelected()){
        btnRegister_Signup.setEnabled(true);
        }
        else{
        btnRegister_Signup.setEnabled(false);
        }
    }//GEN-LAST:event_Terms_SignupActionPerformed

    private void rbtnMale_SignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnMale_SignupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnMale_SignupActionPerformed

    private void rbtnFemale_SignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnFemale_SignupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnFemale_SignupActionPerformed

    private void rbtnNotosay_SignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnNotosay_SignupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnNotosay_SignupActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        Main_GUI m=new Main_GUI();
        m.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtFirstName_SignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFirstName_SignupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFirstName_SignupActionPerformed

    private void txtEmail_SignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmail_SignupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmail_SignupActionPerformed

//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(SignUp_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(SignUp_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(SignUp_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(SignUp_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//      
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new SignUp_GUI().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Terms_Signup;
    private javax.swing.JButton btnRegister_Signup;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAddress_Signup;
    private javax.swing.JLabel lblEmail_Signup;
    private javax.swing.JLabel lblFullName_Signup;
    private javax.swing.JLabel lblGender_Signup;
    private javax.swing.JLabel lblPhoneNumber_Signup;
    private javax.swing.JLabel lblUserName_Signup;
    private javax.swing.JLabel lbladdressmsg;
    private javax.swing.JLabel lblemailmsg;
    private javax.swing.JLabel lblfullnamemsg;
    private javax.swing.JLabel lblgendermsg;
    private javax.swing.JLabel lblphonenumbermsg;
    private javax.swing.JLabel lblpwdmsg;
    private javax.swing.JLabel lblusernamemsg;
    private javax.swing.JLabel msg;
    private javax.swing.JPasswordField pwdPassword_signup;
    private javax.swing.JRadioButton rbtnFemale_Signup;
    private javax.swing.JRadioButton rbtnMale_Signup;
    private javax.swing.JRadioButton rbtnNotosay_Signup;
    private javax.swing.JTextField txtEmail_Signup;
    private javax.swing.JTextField txtFirstName_Signup;
    private javax.swing.JTextField txtPhoneNumber_Signup;
    private javax.swing.JTextField txtUsername_Signup;
    private javax.swing.JTextArea txtareaAddress_Signup;
    private javax.swing.JTextField txtdept;
    // End of variables declaration//GEN-END:variables
}
