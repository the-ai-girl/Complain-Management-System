/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain_management_system;

import javax.swing.JOptionPane;

/**
 *
 * @author PC
 */
public class ComplainForm extends javax.swing.JFrame {

    private int complainID;
    private String uname;

    DbConnection con_obj = new DbConnection();
    RegisterUser log = new RegisterUser();

    /**
     * Creates new form ComplainForm
     */

    public ComplainForm(String uname) {
        this.uname = uname;
        System.out.println(uname);
        log.FetchUser(uname);
        for (String i : log.getUser()) {
            System.out.println(i);
        }
        initComponents();
        setData(log.getUser());
        txtNAme_ComplainForm.setEditable(false);
        txtNum_ComplainForm.setEditable(false);
        txtEmail_ComplainForm.setEditable(false);
    }
    

    private void setData(String[] userD) {
        txtNAme_ComplainForm.setText(userD[0]);
        txtNum_ComplainForm.setText(userD[1]);
        txtEmail_ComplainForm.setText(userD[2]);
        txtDept_ComplainForm.setText(userD[3]);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblName_ComplainForm = new javax.swing.JLabel();
        lblNum_ComplainForm = new javax.swing.JLabel();
        lblEmail_ComplainForm = new javax.swing.JLabel();
        lblDept_ComplainForm = new javax.swing.JLabel();
        lblComplain_ComplainForm = new javax.swing.JLabel();
        chkBox_ComplainForm = new javax.swing.JCheckBox();
        btnSubmit_ComplainForm = new javax.swing.JButton();
        txtNAme_ComplainForm = new javax.swing.JTextField();
        txtNum_ComplainForm = new javax.swing.JTextField();
        txtEmail_ComplainForm = new javax.swing.JTextField();
        txtDept_ComplainForm = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea_ComplainForm = new javax.swing.JTextArea();
        lblPhoneComplain_Form = new javax.swing.JLabel();
        lblNameComplain_Form1 = new javax.swing.JLabel();
        lblNameComplain_Form2 = new javax.swing.JLabel();
        lblEmailComplain_Form3 = new javax.swing.JLabel();
        lbldeptComplain_Form4 = new javax.swing.JLabel();
        lblcpmpComplain_Form5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblName_ComplainForm.setBackground(new java.awt.Color(244, 222, 233));
        lblName_ComplainForm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblName_ComplainForm.setForeground(new java.awt.Color(102, 102, 102));
        lblName_ComplainForm.setText("Name:");
        lblName_ComplainForm.setAutoscrolls(true);
        lblName_ComplainForm.setOpaque(true);
        getContentPane().add(lblName_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, -1, -1));

        lblNum_ComplainForm.setBackground(new java.awt.Color(244, 222, 233));
        lblNum_ComplainForm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblNum_ComplainForm.setForeground(new java.awt.Color(102, 102, 102));
        lblNum_ComplainForm.setText("Phone Number:");
        lblNum_ComplainForm.setOpaque(true);
        getContentPane().add(lblNum_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, -1, -1));

        lblEmail_ComplainForm.setBackground(new java.awt.Color(244, 222, 233));
        lblEmail_ComplainForm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblEmail_ComplainForm.setForeground(new java.awt.Color(102, 102, 102));
        lblEmail_ComplainForm.setText("Email:");
        lblEmail_ComplainForm.setOpaque(true);
        getContentPane().add(lblEmail_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, -1, -1));

        lblDept_ComplainForm.setBackground(new java.awt.Color(244, 222, 233));
        lblDept_ComplainForm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblDept_ComplainForm.setForeground(new java.awt.Color(102, 102, 102));
        lblDept_ComplainForm.setText("Department:");
        lblDept_ComplainForm.setOpaque(true);
        getContentPane().add(lblDept_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, -1));

        lblComplain_ComplainForm.setBackground(new java.awt.Color(244, 222, 233));
        lblComplain_ComplainForm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblComplain_ComplainForm.setForeground(new java.awt.Color(102, 102, 102));
        lblComplain_ComplainForm.setText("Complain:");
        lblComplain_ComplainForm.setOpaque(true);
        getContentPane().add(lblComplain_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, -1, -1));

        chkBox_ComplainForm.setText("I affirms that the above information provided is true?");
        chkBox_ComplainForm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkBox_ComplainFormActionPerformed(evt);
            }
        });
        getContentPane().add(chkBox_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, -1, -1));

        btnSubmit_ComplainForm.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnSubmit_ComplainForm.setText("Submit");
        btnSubmit_ComplainForm.setEnabled(false);
        btnSubmit_ComplainForm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmit_ComplainFormActionPerformed(evt);
            }
        });
        getContentPane().add(btnSubmit_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, -1, -1));
        getContentPane().add(txtNAme_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 134, -1));
        getContentPane().add(txtNum_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 134, -1));
        getContentPane().add(txtEmail_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 134, -1));
        getContentPane().add(txtDept_ComplainForm, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 133, -1));

        txtArea_ComplainForm.setColumns(20);
        txtArea_ComplainForm.setRows(5);
        jScrollPane1.setViewportView(txtArea_ComplainForm);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, -1, -1));
        getContentPane().add(lblPhoneComplain_Form, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 114, 134, 13));
        getContentPane().add(lblNameComplain_Form1, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 67, 134, 15));
        getContentPane().add(lblNameComplain_Form2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 150, 19));
        getContentPane().add(lblEmailComplain_Form3, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 163, 134, 19));
        getContentPane().add(lbldeptComplain_Form4, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 228, 248, 19));
        getContentPane().add(lblcpmpComplain_Form5, new org.netbeans.lib.awtextra.AbsoluteConstraints(477, 331, 82, 19));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton1.setText("Cancel");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 350, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setText("Go Back <-");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Desktop\\mai.jpg")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 570, 400));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void chkBox_ComplainFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkBox_ComplainFormActionPerformed
        // TODO add your handling code here:
        if (chkBox_ComplainForm.isSelected()) {
            btnSubmit_ComplainForm.setEnabled(true);
        } else {
            btnSubmit_ComplainForm.setEnabled(false);
        }
    }//GEN-LAST:event_chkBox_ComplainFormActionPerformed

    private void btnSubmit_ComplainFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmit_ComplainFormActionPerformed

        try {

            String dept = txtDept_ComplainForm.getText();
            String complain = txtArea_ComplainForm.getText();
            log.save(log.getUser()[0],log.getUser()[1],log.getUser()[2],log.getUser()[3],complain);

            //complaint newComplain=new complaint(txtDept_ComplainForm.getText(), txtNAme_ComplainForm.getText(),txtNum_ComplainForm.getText(), txtEmail_ComplainForm.getText(), complainID, txtArea_ComplainForm.getText(), "");
            JOptionPane.showMessageDialog(null, "Complain has been registered \n Please Note Down ComplainID: "+log.getID());
            dispose();

        } catch (Exception e) {
            System.out.println(e);
        }
        dispose();
        UserScreen u=new UserScreen(uname);
        u.setVisible(true);

    }//GEN-LAST:event_btnSubmit_ComplainFormActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int choice = JOptionPane.showConfirmDialog(null, "Do you want to cancel??");
        if (choice == JOptionPane.YES_OPTION) {
            dispose();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        UserScreen us = new UserScreen("jerry");
        us.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(CheckStatus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(CheckStatus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(CheckStatus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(CheckStatus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new ComplainForm().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSubmit_ComplainForm;
    private javax.swing.JCheckBox chkBox_ComplainForm;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblComplain_ComplainForm;
    private javax.swing.JLabel lblDept_ComplainForm;
    private javax.swing.JLabel lblEmailComplain_Form3;
    private javax.swing.JLabel lblEmail_ComplainForm;
    private javax.swing.JLabel lblNameComplain_Form1;
    private javax.swing.JLabel lblNameComplain_Form2;
    private javax.swing.JLabel lblName_ComplainForm;
    private javax.swing.JLabel lblNum_ComplainForm;
    private javax.swing.JLabel lblPhoneComplain_Form;
    private javax.swing.JLabel lblcpmpComplain_Form5;
    private javax.swing.JLabel lbldeptComplain_Form4;
    private javax.swing.JTextArea txtArea_ComplainForm;
    private javax.swing.JTextField txtDept_ComplainForm;
    private javax.swing.JTextField txtEmail_ComplainForm;
    private javax.swing.JTextField txtNAme_ComplainForm;
    private javax.swing.JTextField txtNum_ComplainForm;
    // End of variables declaration//GEN-END:variables

}
