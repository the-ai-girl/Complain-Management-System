
package complain_management_system;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class DbConnection {
     Connection conn=null;
    PreparedStatement st=null;
    ResultSet result=null;
       
    
   public Connection EstablishConnection(){
       try {
           Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
           conn=DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\HP\\Desktop\\cmsfinal\\Complain Management System\\signupdb.accdb");
           //JOptionPane.showMessageDialog(null, "Connected Mwaah<3");
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null, e);
       }
         return conn;
   
   }
   public Connection AdminConnection(){
       try {
           Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
           conn=DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\HP\\Desktop\\cmsfinal\\Complain Management System\\Database\\Database1.accdb");
           //JOptionPane.showMessageDialog(null, "Connected Mwaah<3");
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null, e);
       }
         return conn;
   
   }
   
    
}
